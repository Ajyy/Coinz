#!/usr/bin/env python3
# encoding utf-8

from pathlib import Path
import sys
home = str(Path.home())
sys.path.append(home+'/HFO/example/RL2019-BaseCodes/Exercise2')
from DiscreteHFO.HFOAttackingPlayer import HFOAttackingPlayer
from DiscreteHFO.Agent import Agent
import argparse
import random


class SARSAAgent(Agent):
    def __init__(self, learningRate, discountFactor, epsilon=1.0, initVals=0.0):
        super(SARSAAgent, self).__init__()
        self.learningRate = learningRate
        self.discountFactor = discountFactor
        self.epsilon = epsilon
        self.next_action = None
        self.next_state = None
        self.next_reward = None
        self.current_state = None
        self.current_action = None
        self.current_reward = None
        self.q_table = {}

    def learn(self):
        now_q_value = self.q_table[(self.current_state, self.current_action)]

        # get next q_value using the next state directly
        next_q_value = self.q_table[(self.next_state, self.next_action)] \
            if (self.next_state, self.next_action) in self.q_table and self.next_state != self.current_state else 0

        different = self.learningRate * (self.current_reward + self.discountFactor * next_q_value - now_q_value)

        self.q_table[(self.current_state, self.current_action)] = self.q_table[(
            self.current_state, self.current_action)] + different

        return different

    def act(self):
        rdm = random.uniform(0, 1)
        if rdm > self.epsilon:
            all_values = {}
            max_action = []
            for action in self.possibleActions:
                all_values[action] = self.q_table[(self.next_state, action)]

            for key in all_values:
                if all_values[key] == max(all_values.values()):
                    max_action.append(key)
            return random.choice(max_action)
        else:
            return random.choice(self.possibleActions)

    def setState(self, state):
        self.current_state = self.next_state
        self.next_state = state

    def setExperience(self, state, action, reward, status, nextState):
        if action == None and reward == None and status == None and nextState == None:
            self.current_state = self.next_state
            self.next_state = state
        self.current_action = self.next_action
        self.next_action = action
        self.current_reward = self.next_reward
        self.next_reward = reward

    def computeHyperparameters(self, numTakenActions, episodeNumber):
        epsilon = self.epsilon - 1 / 5001
        learningRate = 0.3
        return learningRate, epsilon

    def toStateRepresentation(self, state):
        for action in self.possibleActions:
            if (state[0], action) not in self.q_table:
                self.q_table[(state[0], action)] = 0
        return state[0]

    def reset(self):
        pass

    def setLearningRate(self, learningRate):
        self.learningRate = learningRate

    def setEpsilon(self, epsilon):
        self.epsilon = epsilon


if __name__ == '__main__':

    parser = argparse.ArgumentParser()
    parser.add_argument('--id', type=int, default=0)
    parser.add_argument('--numOpponents', type=int, default=0)
    parser.add_argument('--numTeammates', type=int, default=0)
    parser.add_argument('--numEpisodes', type=int, default=500)

    args = parser.parse_args()

    numEpisodes = args.numEpisodes
    # Initialize connection to the HFO environment using HFOAttackingPlayer
    hfoEnv = HFOAttackingPlayer(numOpponents=args.numOpponents, numTeammates=args.numTeammates, agentId=args.id)
    hfoEnv.connectToServer()

    # Initialize a SARSA Agent
    agent = SARSAAgent(0.1, 0.99)

    # Run training using SARSA
    numTakenActions = 0
    for episode in range(numEpisodes):
        agent.reset()
        status = 0

        observation = hfoEnv.reset()
        nextObservation = None
        epsStart = True

        while status == 0:
            learningRate, epsilon = agent.computeHyperparameters(numTakenActions, episode)
            agent.setEpsilon(epsilon)
            agent.setLearningRate(learningRate)

            obsCopy = observation.copy()
            agent.setState(agent.toStateRepresentation(obsCopy))
            action = agent.act()
            numTakenActions += 1

            nextObservation, reward, done, status = hfoEnv.step(action)
            # print(obsCopy, action, reward, nextObservation)
            agent.setExperience(agent.toStateRepresentation(obsCopy), action, reward, status,
                                agent.toStateRepresentation(nextObservation))

            if not epsStart:
                agent.learn()
            else:
                epsStart = False

            observation = nextObservation

        agent.setExperience(agent.toStateRepresentation(nextObservation), None, None, None, None)
        agent.learn()
