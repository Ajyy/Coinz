#!/usr/bin/env python3
# encoding utf-8

from pathlib import Path
import sys
home = str(Path.home())
sys.path.append(home+'/HFO/example/RL2019-BaseCodes/Exercise2')
from DiscreteHFO.HFOAttackingPlayer import HFOAttackingPlayer
from DiscreteHFO.Agent import Agent
import argparse
import random


class MonteCarloAgent(Agent):
    def __init__(self, discountFactor, epsilon, initVals=0.0):
        super(MonteCarloAgent, self).__init__()
        self.discountFactor = discountFactor
        self.epsilon = epsilon
        self.q_table = {}
        self.policy = {}
        self.return_list = {}
        self.episode = []
        self.last_state = None
        self.current_state = None

    def learn(self):
        G = 0
        update_q = []
        for time_step in reversed(range(len(self.episode))):
            G = G * self.discountFactor + self.episode[time_step][2]

            # find out whether it appears in the previous steps
            test = 0
            for i in range(time_step):
                if self.episode[time_step][0] == self.episode[i][0] and self.episode[time_step][1] == self.episode[i][1]:
                    test = 1
                    break

            if test == 0:
                # initialize the return_list
                if (self.episode[time_step][0], self.episode[time_step][1]) not in self.return_list:
                    self.return_list[(self.episode[time_step][0], self.episode[time_step][1])] = []

                self.return_list[(self.episode[time_step][0], self.episode[time_step][1])].append(G)

                # update q table
                self.q_table[(self.episode[time_step][0], self.episode[time_step][1])] = \
                    sum(self.return_list[(self.episode[time_step][0], self.episode[time_step][1])]) / \
                    len(self.return_list[(self.episode[time_step][0], self.episode[time_step][1])])

                update_q.append(self.q_table[(self.episode[time_step][0], self.episode[time_step][1])])

                all_values = {}
                max_action = []
                # Choose the action
                for action in self.possibleActions:
                    all_values[action] = self.q_table[(self.episode[time_step][0], action)]

                for key in all_values:
                    if all_values[key] == max(all_values.values()):
                        max_action.append(key)
                action_temp = random.choice(max_action)

                # Update the policy dictionary
                for act in self.possibleActions:
                    if act == action_temp:
                        self.policy[(self.episode[time_step][0], act)] = 1 - self.epsilon + self.epsilon / len(
                            self.possibleActions)
                    else:
                        self.policy[(self.episode[time_step][0], act)] = self.epsilon / len(self.possibleActions)

        update_q = list(reversed(update_q))
        return self.q_table, update_q

    def toStateRepresentation(self, state):
        action_temp = random.choice(self.possibleActions)

        # Initialize parameters
        for action in self.possibleActions:
            if (state[0], action) not in self.q_table:
                self.q_table[(state[0], action)] = 0
            if (state[0], action) not in self.policy:
                if action == action_temp:
                    self.policy[(state[0], action)] = 1 - self.epsilon + self.epsilon / len(self.possibleActions)
                else:
                    self.policy[(state[0], action)] = self.epsilon / len(self.possibleActions)

        return state[0]

    def setExperience(self, state, action, reward, status, nextState):
        self.episode.append((state, action, reward))
        self.action = action

    def setState(self, state):
        if self.current_state == None:
            self.current_state = state
        else:
            self.last_state = self.current_state
            self.current_state = state

    def reset(self):
        self.episode = []
        self.last_state = None
        self.current_state = None

    def act(self):
        possi_action = []

        isSame = 0
        if self.last_state is not None:
            if self.last_state == self.current_state:
                isSame = 1

        for act in self.possibleActions:
            if isSame == 1:
                if self.action != act:
                    possi_action.append(act)
            else:
                possi_action.append(act)

        # epsilon method
        rdm = random.uniform(0, 1)
        if rdm > self.epsilon:
            all_next_actions_p = []
            for action in possi_action:
                all_next_actions_p.append(self.policy[(self.current_state, action)])

            possible_action = []
            for action in possi_action:
                if self.policy[(self.current_state, action)] == max(all_next_actions_p):
                    possible_action.append(action)

            return random.choice(possible_action)
        else:
            return random.choice(possi_action)

    def setEpsilon(self, epsilon):
        self.epsilon = epsilon

    def computeHyperparameters(self, numTakenActions, episodeNumber):
        epsilon = 1-episodeNumber/2500

        return epsilon


if __name__ == '__main__':

    parser = argparse.ArgumentParser()
    parser.add_argument('--id', type=int, default=0)
    parser.add_argument('--numOpponents', type=int, default=0)
    parser.add_argument('--numTeammates', type=int, default=0)
    parser.add_argument('--numEpisodes', type=int, default=500)

    args = parser.parse_args()

    # Init Connections to HFO Server
    hfoEnv = HFOAttackingPlayer(numOpponents=args.numOpponents, numTeammates=args.numTeammates, agentId=args.id)
    hfoEnv.connectToServer()

    # Initialize a Monte-Carlo Agent
    agent = MonteCarloAgent(discountFactor=0.99, epsilon=1.0)
    numEpisodes = args.numEpisodes
    numTakenActions = 0
    # Run training Monte Carlo Method
    for episode in range(numEpisodes):
        agent.reset()
        observation = hfoEnv.reset()
        status = 0

        while status == 0:
            epsilon = agent.computeHyperparameters(numTakenActions, episode)
            agent.setEpsilon(epsilon)
            obsCopy = observation.copy()
            agent.setState(agent.toStateRepresentation(obsCopy))
            action = agent.act()
            numTakenActions += 1
            nextObservation, reward, done, status = hfoEnv.step(action)
            agent.setExperience(agent.toStateRepresentation(obsCopy), action, reward, status,
                                agent.toStateRepresentation(nextObservation))
            observation = nextObservation

        agent.learn()
