#!/usr/bin/env python3
# encoding utf-8
from pathlib import Path
import sys
home = str(Path.home())
sys.path.append(home+'/HFO/example/RL2019-BaseCodes/Exercise2')
from DiscreteHFO.HFOAttackingPlayer import HFOAttackingPlayer
from DiscreteHFO.Agent import Agent
import argparse
import random


class QLearningAgent(Agent):
    def __init__(self, learningRate, discountFactor, epsilon, initVals=0.0):
        super(QLearningAgent, self).__init__()
        self.learningRate = learningRate
        self.discountFactor = discountFactor
        self.epsilon = epsilon
        self.q_table = {}

    def learn(self):
        now_q_value = self.q_table[(self.current_state, self.action)]

        next_q_value = 0
        # For the situdation that player wants to be outside the bound
        if self.next_state == self.current_state:
            if now_q_value < 0:
                next_q_value = 1.1*now_q_value
        else:
            all_next_values = []
            for action in self.possibleActions:
                all_next_values.append(self.q_table[(self.next_state, action)])
            next_q_value = max(all_next_values)

        # get the different
        different = self.learningRate * (self.reward + self.discountFactor * next_q_value - now_q_value)

        self.q_table[(self.current_state, self.action)] = self.q_table[(self.current_state, self.action)] + different

        return different

    def act(self):
        # epsilon method
        rdm = random.uniform(0, 1)
        if rdm > self.epsilon:
            all_values = {}
            max_action = []
            for action in self.possibleActions:
                all_values[action] = self.q_table[(self.current_state, action)]

            for key in all_values:
                if all_values[key] == max(all_values.values()):
                    max_action.append(key)
            return random.choice(max_action)
        else:
            return random.choice(self.possibleActions)

    def toStateRepresentation(self, state):
        # Initialize the parameters
        for action in self.possibleActions:
            if (state[0], action) not in self.q_table:
                self.q_table[(state[0], action)] = 0

        self.statee = state
        return state[0]

    def setState(self, state):
        self.current_state = state

    def setExperience(self, state, action, reward, status, nextState):
        self.next_state = nextState
        self.action = action
        self.reward = reward

    def setLearningRate(self, learningRate):
        self.learningRate = learningRate

    def setEpsilon(self, epsilon):
        self.epsilon = epsilon

    def reset(self):
        raise NotImplementedError

    def computeHyperparameters(self, numTakenActions, episodeNumber):
        epsilon = 1 - episodeNumber / 1500
        learningRate = 0.3
        return learningRate, epsilon


if __name__ == '__main__':

    parser = argparse.ArgumentParser()
    parser.add_argument('--id', type=int, default=0)
    parser.add_argument('--numOpponents', type=int, default=0)
    parser.add_argument('--numTeammates', type=int, default=0)
    parser.add_argument('--numEpisodes', type=int, default=500)

    args = parser.parse_args()

    # Initialize connection with the HFO server
    hfoEnv = HFOAttackingPlayer(numOpponents=args.numOpponents, numTeammates=args.numTeammates, agentId=args.id)
    hfoEnv.connectToServer()

    # Initialize a Q-Learning Agent
    agent = QLearningAgent(learningRate=0.1, discountFactor=0.99, epsilon=1.0)
    numEpisodes = args.numEpisodes

    # Run training using Q-Learning
    numTakenActions = 0
    for episode in range(numEpisodes):
        status = 0
        observation = hfoEnv.reset()

        while status == 0:
            learningRate, epsilon = agent.computeHyperparameters(numTakenActions, episode)
            agent.setEpsilon(epsilon)
            agent.setLearningRate(learningRate)

            obsCopy = observation.copy()
            agent.setState(agent.toStateRepresentation(obsCopy))
            action = agent.act()
            numTakenActions += 1

            nextObservation, reward, done, status = hfoEnv.step(action)
            agent.setExperience(agent.toStateRepresentation(obsCopy), action, reward, status,
                                agent.toStateRepresentation(nextObservation))
            update = agent.learn()

            observation = nextObservation
