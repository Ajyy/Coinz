#!/usr/bin/env python3
# encoding utf-8

import random
import argparse
from DiscreteMARLUtils.Environment import DiscreteMARLEnvironment
from DiscreteMARLUtils.Agent import Agent
from copy import deepcopy
import argparse

count = 0
oppo = None


class IndependentQLearningAgent(Agent):
    def __init__(self, learningRate, discountFactor, epsilon, initVals=0.0):
        super(IndependentQLearningAgent, self).__init__()
        self.learningRate = learningRate
        self.discountFactor = discountFactor
        self.epsilon = epsilon
        self.q_table = {}

    def setExperience(self, state, action, reward, status, nextState):
        self.next_state = nextState
        self.action = action
        self.reward = reward

    def learn(self):
        global count, oppo
        for action2 in self.possibleActions:
            if (self.current_state, action2) not in self.q_table:
                self.q_table[(self.current_state, action2)] = 0

            if (self.next_state, action2) not in self.q_table:
                self.q_table[(self.next_state, action2)] = 0
        now_q_value = self.q_table[(self.current_state, self.action)]

        # For the situation that players want to be outside the bounds
        if self.next_state[count] == self.current_state[count] and self.action != 'KICK' and self.action != 'NO_OP':
            if now_q_value >= 0:
                next_q_value = 0
            else:
                next_q_value = now_q_value * 1.2
        else:
            all_next_values = []
            for action in self.possibleActions:
                all_next_values.append(self.q_table[(self.next_state, action)])
            next_q_value = max(all_next_values)

        different = self.learningRate * (self.reward + self.discountFactor * next_q_value - now_q_value)
        if self.reward == -0.4 and oppo != self.next_state[count]:
            different2 = self.learningRate * (self.discountFactor * next_q_value - now_q_value)
            self.q_table[(self.current_state, self.action)] = self.q_table[
                                                                  (self.current_state, self.action)] + different2
        else:
            self.q_table[(self.current_state, self.action)] = self.q_table[
                                                                  (self.current_state, self.action)] + different
        if count == 1:
            count = 0
        else:
            count = 1

        return different

    def act(self):
        for action2 in self.possibleActions:
            if (self.current_state, action2) not in self.q_table:
                self.q_table[(self.current_state, action2)] = 0

        rdm = random.uniform(0, 1)
        if rdm > self.epsilon:
            all_values = {}
            max_action = []
            for action in self.possibleActions:
                all_values[action] = self.q_table[(self.current_state, action)]

            for key in all_values:
                if all_values[key] == max(all_values.values()):
                    max_action.append(key)
            return random.choice(max_action)
        else:
            return random.choice(self.possibleActions)

    def toStateRepresentation(self, state):
        global oppo
        if len(state) == 3:
            # Three situations for the ball position
            if state[0][0] == state[2][0]:
                a = (tuple(state[0][0]), tuple(state[0][1]), '1')
            elif state[0][1] == state[2][0]:
                a = (tuple(state[0][0]), tuple(state[0][1]), '2')
            else:
                a = (tuple(state[0][0]), tuple(state[0][1]), '3')
            oppo = tuple(state[1][0])
            return tuple(a)
        else:
            return state, state

    def setState(self, state):
        self.current_state = state

    def setEpsilon(self, epsilon):
        self.epsilon = epsilon

    def setLearningRate(self, learningRate):
        self.learningRate = learningRate

    def computeHyperparameters(self, numTakenActions, episodeNumber):
        epsilon = 1 - episodeNumber / 25000
        learningRate = 0.3
        return learningRate, epsilon


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--numOpponents', type=int, default=1)
    parser.add_argument('--numAgents', type=int, default=2)
    parser.add_argument('--numEpisodes', type=int, default=50000)

    args = parser.parse_args()

    MARLEnv = DiscreteMARLEnvironment(numOpponents=args.numOpponents, numAgents=args.numAgents)
    agents = []
    for i in range(args.numAgents):
        agent = IndependentQLearningAgent(learningRate=0.1, discountFactor=0.9, epsilon=1.0)
        agents.append(agent)

    numEpisodes = args.numEpisodes
    numTakenActions = 0
    for episode in range(numEpisodes):
        status = ["IN_GAME", "IN_GAME", "IN_GAME"]
        observation = MARLEnv.reset()
        totalReward = 0.0
        timeSteps = 0

        while status[0] == "IN_GAME":
            for agent in agents:
                learningRate, epsilon = agent.computeHyperparameters(numTakenActions, episode)
                agent.setEpsilon(epsilon)
                agent.setLearningRate(learningRate)
            actions = []
            stateCopies = []
            for agentIdx in range(args.numAgents):
                obsCopy = deepcopy(observation[agentIdx])
                stateCopies.append(obsCopy)
                agents[agentIdx].setState(agent.toStateRepresentation(obsCopy))
                actions.append(agents[agentIdx].act())
            numTakenActions += 1
            nextObservation, reward, done, status = MARLEnv.step(actions)

            for agentIdx in range(args.numAgents):
                agents[agentIdx].setExperience(agent.toStateRepresentation(stateCopies[agentIdx]), actions[agentIdx],
                                               reward[agentIdx],
                                               status[agentIdx], agent.toStateRepresentation(nextObservation[agentIdx]))
                agents[agentIdx].learn()

            observation = nextObservation