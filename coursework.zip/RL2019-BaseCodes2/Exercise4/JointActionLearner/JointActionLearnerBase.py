#!/usr/bin/env python3
# encoding utf-8

import random
import argparse
from DiscreteMARLUtils.Environment import DiscreteMARLEnvironment
from DiscreteMARLUtils.Agent import Agent
from copy import deepcopy
import itertools
import argparse

count = 0


class JointQLearningAgent(Agent):
    def __init__(self, learningRate, discountFactor, epsilon, numTeammates, initVals=0.0):
        super(JointQLearningAgent, self).__init__()
        self.learningRate = learningRate
        self.discountFactor = discountFactor
        self.epsilon = epsilon
        self.numTeammates = numTeammates
        self.q_table = {}
        self.count = {}
        self.n = {}

    def setExperience(self, state, action, oppoActions, reward, status, nextState):
        self.next_state = nextState
        self.action = action
        self.reward = reward
        self.oppoActions = oppoActions

    def learn(self):
        # count for the present player
        global count
        for action1 in self.possibleActions:
            for action2 in self.possibleActions:
                if (self.current_state, action1, action2) not in self.q_table:
                    self.q_table[(self.current_state, action1, action2)] = 0
                if (self.next_state, action1, action2) not in self.q_table:
                    self.q_table[(self.next_state, action1, action2)] = 0
            if (self.next_state, action1) not in self.count:
                self.count[(self.next_state, action1)] = 0
            if (self.current_state, action1) not in self.count:
                self.count[(self.current_state, action1)] = 0

        if self.next_state not in self.n:
            self.n[self.next_state] = 0

        if self.current_state not in self.n:
            self.n[self.current_state] = 0

        now_q_value = self.q_table[(self.current_state, self.action, self.oppoActions[0])]

        # For the situation that players want to be outside the bounds
        if self.n[self.next_state] == 0 or self.next_state[count] == self.current_state[
            count] and self.action != 'KICK' and self.action != 'NO_OP':
            if now_q_value >= 0:
                next_q_value = -now_q_value
            else:
                next_q_value = now_q_value * 1.2
        else:
            all_values = {}
            for action1 in self.possibleActions:
                sum_sub = 0
                for action2 in self.possibleActions:
                    sum_sub = sum_sub + self.count[(self.next_state, action2)] * \
                              self.q_table[(self.next_state, action1, action2)] / \
                              self.n[self.next_state]
                all_values[action1] = sum_sub

            next_q_value = max(all_values.values())

        different = self.learningRate * (self.reward + self.discountFactor * next_q_value - now_q_value)
        # if one is on the position of opponent, get -0.4 reward but teammates reward is 0
        if self.reward == -0.4 and oppo != self.next_state[count]:
            different2 = self.learningRate * (self.discountFactor * next_q_value - now_q_value)
            self.q_table[(self.current_state, self.action, self.oppoActions[0])] = \
                self.q_table[(self.current_state, self.action, self.oppoActions[0])] + different2
        else:
            self.q_table[(self.current_state, self.action, self.oppoActions[0])] = \
                self.q_table[(self.current_state, self.action, self.oppoActions[0])] + different

        self.n[self.current_state] = self.n[self.current_state] + 1
        self.count[(self.current_state, self.oppoActions[0])] = self.count[
                                                                    (self.current_state, self.oppoActions[0])] + 1
        # update count
        if count == 1:
            count = 0
        else:
            count = 1

        return different

    def act(self):
        for action1 in self.possibleActions:
            for action2 in self.possibleActions:
                if (self.current_state, action1, action2) not in self.q_table:
                    self.q_table[(self.current_state, action1, action2)] = 0
            if (self.current_state, action1) not in self.count:
                self.count[(self.current_state, action1)] = 0

        if self.current_state not in self.n:
            self.n[self.current_state] = 0

        all_values = {}
        max_action = []
        if self.n[self.current_state] == 0:
            return random.choice(self.possibleActions)

        rdm = random.uniform(0, 1)
        if rdm > self.epsilon:
            for action1 in self.possibleActions:
                sum_sub = 0
                for action2 in self.possibleActions:
                    sum_sub = sum_sub + self.count[(self.current_state, action2)] * \
                              self.q_table[(self.current_state, action1, action2)] / \
                              self.n[self.current_state]
                all_values[action1] = sum_sub
            for key in all_values:
                if all_values[key] == max(all_values.values()):
                    max_action.append(key)
            return random.choice(max_action)
        else:
            return random.choice(self.possibleActions)

    def setEpsilon(self, epsilon):
        self.epsilon = epsilon

    def setLearningRate(self, learningRate):
        self.learningRate = learningRate

    def setState(self, state):
        self.current_state = state

    def toStateRepresentation(self, rawState):
        global oppo
        if len(rawState) == 3:
            # Three situations for the ball position
            if rawState[0][0] == rawState[2][0]:
                a = (tuple(rawState[0][0]), tuple(rawState[0][1]), '1')
            elif rawState[0][1] == rawState[2][0]:
                a = (tuple(rawState[0][0]), tuple(rawState[0][1]), '2')
            else:
                a = (tuple(rawState[0][0]), tuple(rawState[0][1]), '3')
            oppo = tuple(rawState[1][0])
            return tuple(a)
        else:
            return rawState, rawState

    def computeHyperparameters(self, numTakenActions, episodeNumber):
        if episodeNumber <= 25000:
            epsilon = 1 - episodeNumber / 50000
        else:
            epsilon = 0
        learningRate = 0.25
        return learningRate, epsilon


if __name__ == '__main__':

    parser = argparse.ArgumentParser()
    parser.add_argument('--numOpponents', type=int, default=1)
    parser.add_argument('--numAgents', type=int, default=2)
    parser.add_argument('--numEpisodes', type=int, default=50000)

    args = parser.parse_args()

    MARLEnv = DiscreteMARLEnvironment(numOpponents=args.numOpponents, numAgents=args.numAgents)
    agents = []
    numAgents = args.numAgents
    numEpisodes = args.numEpisodes
    for i in range(numAgents):
        agent = JointQLearningAgent(learningRate=0.1, discountFactor=0.9, epsilon=1.0, numTeammates=args.numAgents - 1)
        agents.append(agent)

    numEpisodes = numEpisodes
    numTakenActions = 0

    reward_sum = 0
    for episode in range(numEpisodes):
        status = ["IN_GAME", "IN_GAME", "IN_GAME"]
        observation = MARLEnv.reset()

        while status[0] == "IN_GAME":
            for agent in agents:
                learningRate, epsilon = agent.computeHyperparameters(numTakenActions, episode)
                agent.setEpsilon(epsilon)
                agent.setLearningRate(learningRate)
            actions = []
            stateCopies = []
            for agentIdx in range(args.numAgents):
                obsCopy = deepcopy(observation[agentIdx])
                stateCopies.append(obsCopy)
                agents[agentIdx].setState(agents[agentIdx].toStateRepresentation(obsCopy))
                actions.append(agents[agentIdx].act())

            nextObservation, reward, done, status = MARLEnv.step(actions)
            numTakenActions += 1
            reward_sum = reward_sum + reward[0]
            numTakenActions += 1
            if reward[0] != 0 and reward[0] != 1:
                print(nextObservation, reward, actions)

            for agentIdx in range(args.numAgents):
                oppoActions = actions.copy()
                del oppoActions[agentIdx]
                agents[agentIdx].setExperience(agents[agentIdx].toStateRepresentation(stateCopies[agentIdx]),
                                               actions[agentIdx], oppoActions,
                                               reward[agentIdx], status[agentIdx],
                                               agent.toStateRepresentation(nextObservation[agentIdx]))
                agents[agentIdx].learn()

            observation = nextObservation
        print(nextObservation, reward, actions, agents[0].current_state, episode)
        print(reward_sum / (episode + 1))
