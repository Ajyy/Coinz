#!/usr/bin/env python3
# encoding utf-8
import sys
sys.path.append('/afs/inf.ed.ac.uk/user/s15/s1504904/HFO/example/RL2019-BaseCodes/Exercise4')
import random
import argparse
from DiscreteMARLUtils.Environment import DiscreteMARLEnvironment
from DiscreteMARLUtils.Agent import Agent
from copy import deepcopy

oppo = None
count = 0
class WolfPHCAgent(Agent):
    def __init__(self, learningRate, discountFactor, winDelta=0.01, loseDelta=0.1, initVals=0.0):
        super(WolfPHCAgent, self).__init__()
        self.learningRate = learningRate
        self.winDelta = winDelta
        self.loseDelta = loseDelta
        self.discountFactor = discountFactor
        self.count = {}
        self.q_table = {}
        self.policy = {}
        self.ave_policy = {}

    def setExperience(self, state, action, reward, status, nextState):
        self.next_state = nextState
        self.action = action
        self.reward = reward

    def learn(self):
        # count for the present player and initialize the parameters
        global count
        for action in self.possibleActions:
            if (self.next_state, action) not in self.q_table:
                self.q_table[(self.next_state, action)] = 0

            if (self.next_state, action) not in self.policy:
                self.policy[(self.next_state, action)] = 1 / len(self.possibleActions)

            if (self.next_state, action) not in self.ave_policy:
                self.ave_policy[(self.next_state, action)] = 1 / len(self.possibleActions)

            if (self.current_state, action) not in self.q_table:
                self.q_table[(self.current_state, action)] = 0

            if (self.current_state, action) not in self.policy:
                self.policy[(self.current_state, action)] = 1 / len(self.possibleActions)

            if (self.current_state, action) not in self.ave_policy:
                self.ave_policy[(self.current_state, action)] = 1 / len(self.possibleActions)

        if self.current_state not in self.count:
            self.count[self.next_state] = 0

        now_q_value = self.q_table[(self.current_state, self.action)]

        if self.next_state[count] == self.current_state[count] and self.action != 'KICK' and self.action != 'NO_OP':
            if now_q_value >= 0:
                next_q_value = 0
            else:
                next_q_value = now_q_value*1.2
        else:
            all_next_values = []
            for action in self.possibleActions:
                all_next_values.append(self.q_table[(self.next_state, action)])
            next_q_value = max(all_next_values)

        different = self.learningRate * (self.reward + self.discountFactor * next_q_value - now_q_value)
        if self.reward == -0.4 and oppo != self.next_state[count]:
            different2 = self.learningRate * (self.discountFactor * next_q_value - now_q_value)
            self.q_table[(self.current_state, self.action)] = self.q_table[(self.current_state, self.action)] + different2
        else:
            self.q_table[(self.current_state, self.action)] = self.q_table[
                                                                  (self.current_state, self.action)] + different

        self.q_table[(self.current_state, self.action)] = self.q_table[(self.current_state, self.action)] + different

        # update count
        if count == 1:
            count = 0
        else:
            count = 1

        return different

    def act(self):
        # initialize the parameters
        for action in self.possibleActions:
            if (self.current_state, action) not in self.q_table:
                self.q_table[(self.current_state, action)] = 0

            if (self.current_state, action) not in self.policy:
                self.policy[(self.current_state, action)] = 1 / len(self.possibleActions)

            if (self.current_state, action) not in self.ave_policy:
                self.ave_policy[(self.current_state, action)] = 1 / len(self.possibleActions)

        if self.current_state not in self.count:
            self.count[self.current_state] = 0

        all_values = {}
        max_action = []
        for action in self.possibleActions:
            all_values[action] = self.policy[(self.current_state, action)]

        for key in all_values:
            if all_values[key] == max(all_values.values()):
                max_action.append(key)
        return random.choice(max_action)

    def calculateAveragePolicyUpdate(self):
        # initialize count dictionary
        if self.current_state not in self.count:
            self.count[self.current_state] = 0
        self.count[self.current_state] = self.count[self.current_state] + 1
        result = []
        for action in self.possibleActions:
            self.ave_policy[(self.current_state, action)] = self.ave_policy[(self.current_state, action)] \
                                                            + (self.policy[(self.current_state, action)] -
                                                               self.ave_policy[(self.current_state, action)]) \
                                                            / self.count[self.current_state]
            result.append(self.ave_policy[(self.current_state, action)])
        return result

    def calculatePolicyUpdate(self):
        # initialize the parameters
        for action in self.possibleActions:
            if (self.current_state, action) not in self.q_table:
                self.q_table[(self.current_state, action)] = 0

            if (self.current_state, action) not in self.policy:
                self.policy[(self.current_state, action)] = 1 / len(self.possibleActions)

            if (self.current_state, action) not in self.ave_policy:
                self.ave_policy[(self.current_state, action)] = 1 / len(self.possibleActions)

        sum_ave = 0
        sum_now = 0
        for action in self.possibleActions:
            sum_now = sum_now+self.policy[(self.current_state, action)]*self.q_table[(self.current_state, action)]
            sum_ave = sum_ave+self.ave_policy[(self.current_state, action)]*self.q_table[(self.current_state, action)]

        delta = self.winDelta if sum_now >= sum_ave else self.loseDelta
        p_moved = 0
        max_action = []
        q_max = -9999999999999999
        for action in self.possibleActions:
            if q_max < self.q_table[(self.current_state, action)]:
                q_max = self.q_table[(self.current_state, action)]

        for action in self.possibleActions:
            if self.q_table[(self.current_state, action)] == q_max:
                max_action.append(action)

        # update policy
        result = []
        for action in self.possibleActions:
            if action not in max_action:
                p_moved = p_moved + \
                          min([delta/(len(self.possibleActions) - len(max_action)),
                               self.policy[self.current_state, action]])
                self.policy[self.current_state, action] = \
                    self.policy[self.current_state, action] - \
                    min([delta / (len(self.possibleActions) - len(max_action)),
                         self.policy[self.current_state, action]])

        for action in max_action:
            self.policy[self.current_state, action] = self.policy[self.current_state, action] + \
                                                      p_moved/len(max_action)

        for action in self.possibleActions:
            result.append(self.policy[self.current_state, action])

        return result

    def toStateRepresentation(self, state):
        global oppo
        if len(state) == 3:
            # Three situations for the ball position
            if state[0][0] == state[2][0]:
                a = (tuple(state[0][0]), tuple(state[0][1]), '1')
            elif state[0][1] == state[2][0]:
                a = (tuple(state[0][0]), tuple(state[0][1]), '2')
            else:
                a = (tuple(state[0][0]), tuple(state[0][1]), '3')
            oppo = tuple(state[1][0])
            return tuple(a)
        else:
            return state,state

    def setState(self, state):
        self.current_state = state

    def setLearningRate(self, lr):
        self.learningRate = lr

    def setWinDelta(self, winDelta):
        self.winDelta = winDelta

    def setLoseDelta(self, loseDelta):
        self.loseDelta = loseDelta

    def computeHyperparameters(self, numTakenActions, episodeNumber):
        learningRate = 0.1
        loseDelta = 4e-5
        winDelta = 1e-5
        return loseDelta, winDelta, learningRate

if __name__ == '__main__':

    parser = argparse.ArgumentParser()
    parser.add_argument('--numOpponents', type=int, default=1)
    parser.add_argument('--numAgents', type=int, default=2)
    parser.add_argument('--numEpisodes', type=int, default=100000)

    args=parser.parse_args()

    numOpponents = args.numOpponents
    numAgents = args.numAgents
    MARLEnv = DiscreteMARLEnvironment(numOpponents = numOpponents, numAgents = numAgents)

    agents = []
    for i in range(args.numAgents):
        agent = WolfPHCAgent(learningRate = 0.2, discountFactor = 0.99, winDelta=0.01, loseDelta=0.1)
        agents.append(agent)

    numEpisodes = args.numEpisodes
    numTakenActions = 0
    reward_sum = 0
    for episode in range(numEpisodes):
        print(episode)
        status = ["IN_GAME","IN_GAME","IN_GAME"]
        observation = MARLEnv.reset()

        while status[0]=="IN_GAME":
            for agent in agents:
                loseDelta, winDelta, learningRate = agent.computeHyperparameters(numTakenActions, episode)
                agent.setLoseDelta(loseDelta)
                agent.setWinDelta(winDelta)
                agent.setLearningRate(learningRate)
            actions = []
            perAgentObs = []
            agentIdx = 0
            for agent in agents:
                obsCopy = deepcopy(observation[agentIdx])
                perAgentObs.append(obsCopy)
                agent.setState(agent.toStateRepresentation(obsCopy))
                actions.append(agent.act())
                agentIdx += 1
            nextObservation, reward, done, status = MARLEnv.step(actions)
            numTakenActions += 1
            if reward[0] != 0 and reward[0] != 1:
                print(nextObservation, reward, actions)
            reward_sum = reward_sum + reward[0]
            agentIdx = 0
            for agent in agents:
                agent.setExperience(agent.toStateRepresentation(perAgentObs[agentIdx]), actions[agentIdx], reward[agentIdx],
                    status[agentIdx], agent.toStateRepresentation(nextObservation[agentIdx]))
                agent.learn()
                agent.calculateAveragePolicyUpdate()
                agent.calculatePolicyUpdate()
                agentIdx += 1

            observation = nextObservation
        print(nextObservation, reward, actions, agents[0].current_state, oppo)
        print(reward_sum / (episode + 1))