import torch
import torch.nn as nn
import torch.nn.functional as F

import math

# Define your neural networks in this class. 
# Use the __init__ method to define the architecture of the network
# and define the computations for the forward pass in the forward method.


class ValueNetwork(nn.Module):
    # Simple two-layers feedforward nerual network
    def __init__(self):
        super(ValueNetwork, self).__init__()
        self.fc1 = nn.Linear(15, 8)
        self.fc2 = nn.Linear(8, 4)
        self.tanh = nn.Tanh()
        self.softmax = F.softmax

    def forward(self, inputs):
        out = self.fc1(inputs)
        out = self.fc2(self.tanh(out))
        out = self.softmax(out, dim=1)
        return out
