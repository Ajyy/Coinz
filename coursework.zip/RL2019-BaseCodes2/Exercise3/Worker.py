import torch
import torch.nn as nn
import torch.optim as optim

from Environment import HFOEnv
import random

def train(idx, args, targetNetwork, valueNetwork, lock, counter):
    port = 8700 + idx * 10
    seed = args.seed + idx
    t = 0
    i_target = 1000
    i_async_update = 50
    valueNetwork.train()
    optimizer = optim.Adam(valueNetwork.parameters(), lr=1e-5)
    criterion = nn.MSELoss()

    # Get the initial env
    hfoEnv = HFOEnv(numTeammates=args.numTeammates, numOpponents=args.numOpponents, port=port, seed=seed)
    hfoEnv.connectToServer()
    observation = torch.from_numpy(hfoEnv.reset())

    # Set epsilon and discount factor
    epsilon = 1
    discountFactor = 0.99
    # While less than 32,000,000
    while counter.value < args.numTimestep:
        # Epsilon method choose action
        rdm = random.uniform(0, 1)
        if rdm > epsilon:
            lock.acquire()
            out = valueNetwork(observation.unsqueeze(0))
            lock.release()
            action = hfoEnv.possibleActions[torch.argmax(out, dim=1).item()]
        else:
            action = random.choice(hfoEnv.possibleActions)

        # Update epsilon
        if epsilon > 0:
            epsilon = epsilon-1/ 1000000

        newObservation, reward, done, status, info = hfoEnv.step(action)
        newObservation = torch.from_numpy(newObservation)
        lock.acquire()

        # Get target value and predicted value by value network
        y_value = computePrediction(observation.unsqueeze(0), hfoEnv.possibleActions.index(action), valueNetwork)
        y = computeTargets(reward, newObservation.unsqueeze(0), discountFactor, done, targetNetwork)
        lock.release()
        loss = criterion(y_value, y)
        loss.backward()
        lock.acquire()
        counter.value = counter.value + 1
        lock.release()
        t = t + 1
        observation = newObservation

        # If get 0, update targetNetwork
        if counter.value % i_target == 0:
            targetNetwork.load_state_dict(valueNetwork.state_dict())

        # If get 0 or done, update the value network
        if done or t % i_async_update == 0:
            optimizer.step()
            optimizer.zero_grad()

            # If done initialize the env
            if done:
                observation = torch.from_numpy(hfoEnv.reset())

def computeTargets(reward, nextObservation, discountFactor, done, targetNetwork):
    next_q = targetNetwork(nextObservation)
    if done:
        y = torch.Tensor([reward])
    else:
        y = torch.Tensor([reward]) + discountFactor * torch.max(next_q[0])

    return y


def computePrediction(state, action, valueNetwork):
    a = valueNetwork(state)[0, action]
    return a


# Function to save parameters of a neural network in pytorch.
def saveModelNetwork(model, strDirectory):
    torch.save(model.state_dict(), strDirectory)
