#!/usr/bin/env python3
# encoding utf-8
import argparse
import os
import torch
import torch.multiprocessing as mp

from Networks import ValueNetwork
from Worker import train

# Use this script to handle arguments and 
# initialize important components of your experiment.
# These might include important parameters for your experiment, and initialization of
# your models, torch's multiprocessing methods, etc.
parser = argparse.ArgumentParser(description='A3C RL')
parser.add_argument('--seed', type=int, default=1, metavar='S')
parser.add_argument('--numProcesses', type=int, default=8, metavar='N')
parser.add_argument('--numTeammates', type=int, default=0)
parser.add_argument('--numOpponents', type=int, default=1)
parser.add_argument('--numTimestep', type=int, default=32000000)
# Training settings
if __name__ == "__main__":

    # Example on how to initialize global locks for processes
    # and counters.
    args = parser.parse_args()
    counter = mp.Value('i', 0)
    counter_episode = mp.Value('i', 0)
    sum_ts = mp.Value('i', 0)
    lock = mp.Lock()

    torch.manual_seed(args.seed)

    processes = []
    targetNetwork = ValueNetwork()
    valueNetwork = ValueNetwork()
    valueNetwork.load_state_dict(targetNetwork.state_dict())
    targetNetwork.share_memory()
    valueNetwork.share_memory()

    for idx in range(0, args.numProcesses):
        trainingArgs = (idx, args, targetNetwork, valueNetwork, lock, counter)
        p = mp.Process(target=train, args=trainingArgs)
        p.start()
        processes.append(p)
    for p in processes:
        p.join()




