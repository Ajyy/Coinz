from MDP import MDP


class BellmanDPSolver(object):
    def __init__(self, discountRate):
        self.MDP = MDP()
        self.initVs()
        self.discountRate = discountRate

    def initVs(self):
        self.value_state = dict.fromkeys(self.MDP.S, 0)
        self.policy = dict.fromkeys(self.MDP.S, self.MDP.A.copy())

    def BellmanUpdate(self):
        # Store the value-state value for updating
        value_state_temp = self.value_state.copy()
        for init_state in self.value_state:
            values = dict.fromkeys(self.MDP.A, 0)
            for action in self.MDP.A:
                value = 0
                probability = self.MDP.probNextStates(init_state, action)
                for next_state in probability:
                    reward = self.MDP.getRewards(init_state, action, next_state)
                    # get value
                    value = value + probability[next_state] * \
                            (reward + self.discountRate * value_state_temp[next_state])

                values[action] = value

            # Update value_state and policy
            self.value_state[init_state] = max(values.values())
            self.policy[init_state] = [action for action in values.keys() if values[action] == max(values.values())]

        return self.value_state, self.policy


if __name__ == '__main__':
    solution = BellmanDPSolver(1)
    for i in range(20000):
        values, policy = solution.BellmanUpdate()
    print("Values : ", values)
    print("Policy : ", policy)
